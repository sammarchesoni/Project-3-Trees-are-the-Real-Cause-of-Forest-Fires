<?php
/*
Plugin Name: BRAZIL JS MAP
Plugin URI: https://www.html5interactivemaps.com/
Description: Customize the colors, links, etc and use the shortcode in your pages.
Version: 4.1
Author: HTML5 Interactive Maps
Author URI: https://www.html5interactivemaps.com/
*/
class BRJSMAP {
  public function __construct(){
    $this->constant();
    $this->options = get_option( 'br_js_map' );
    add_action( 'admin_menu', array($this, 'br_js_map_options_page') );
    add_action( 'admin_footer', array( $this,'add_js_to_wp_footer') );
    add_action( 'wp_footer', array($this,'add_span_tag') );
    add_action( 'admin_enqueue_scripts', array($this,'init_admin_script') );
    add_shortcode( 'br_js_map', array($this, 'br_js_map') );
  }
  protected function constant(){
    define( 'BRJSMAP_VERSION', '1.0' );
    define( 'BRJSMAP_DIR', plugin_dir_path( __FILE__ ) );
    define( 'BRJSMAP_URL', plugin_dir_url( __FILE__ ) );
  }
  public function br_js_map(){
    ob_start();
    include 'design/map.php';
    ?>
    <?php
    wp_enqueue_style( 'br-js-mapstyle-frontend', BRJSMAP_URL . 'map-style.css', false, '1.0', 'all' );
    wp_enqueue_script( 'br-js-map-config', BRJSMAP_URL . 'map-config.js', array('jquery'), 10, '1.0', true );
    wp_enqueue_script( 'br-js-pins-config', BRJSMAP_URL . 'pins-config.js', array('jquery'), 10, '1.0', true );
    wp_enqueue_script( 'br-js-map-interact', BRJSMAP_URL . 'map-interact.js', array('jquery'), 10, '1.0', true );
    $html = ob_get_clean();
    return $html;
  }
  public function br_js_map_options_page() {
    add_menu_page('Brazil JS Map', 'Brazil JS Map', 'manage_options', 'br-js-map', array($this, 'options_screen'), BRJSMAP_URL . 'design/map-icon.png');
  }
  public function admin_ajax_url(){
    $url_action = admin_url( '/' ) . 'admin-ajax.php';
    echo '<div style="display:none" id="wpurl">'. $url_action.'</div>';
  }
	public function options_screen(){ 
    ?>
    <?php include 'design/admin.php';
  }
  public function add_js_to_wp_footer(){
    ?>
    <span id="brjstip" style="margin-top:-32px"></span>
    <?php
  }
  public function add_span_tag(){
    ?>
    <span id="brjstip"></span>
    <?php
  }
  public function stripslashes_deep($value) {
    $value = is_array($value) ?
    array_map(array($this, 'stripslashes_deep'), $value) : stripslashes($value);
    return $value;
  }
  public function init_admin_script(){
    if(isset($_GET['page']) && $_GET['page'] == 'br-js-map'):
      wp_enqueue_style( 'br-js-map-style', BRJSMAP_URL . 'map-admin-style.css', false, '1.0', 'all' );
      wp_enqueue_style( 'br-js-mapstyle', BRJSMAP_URL . 'map-style.css', false, '1.0', 'all' );
      wp_enqueue_script( 'br-js-map-config', BRJSMAP_URL . 'map-config.js', array('jquery'), 10, '1.0', true );
      wp_enqueue_script( 'br-js-pins-config', BRJSMAP_URL . 'pins-config.js', array('jquery'), 10, '1.0', true );
      wp_enqueue_script( 'br-js-map-interact', BRJSMAP_URL . 'map-interact.js', array('jquery'), 10, '1.0', true );
      endif;
  }
}
$br_js_map = new BRJSMAP();