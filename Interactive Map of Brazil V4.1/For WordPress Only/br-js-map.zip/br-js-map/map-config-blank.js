﻿// This is similar to "map-config.js" with basic settings (colors, info., etc)
var brjsconfig = {
  "brjs1":{
    "hover": "ACRE",//info of the popup
    "url": "https://www.html5interactivemaps.com/",//link to any webpage
    "target": "same_window",// use "new_window", "same_window", "modal", or "none"
    "upColor": "#FFFFF3",//default color
    "overColor": "#ECFFB3",//highlight color
    "downColor": "#cae9af",//clicking color
    "active": true//true/false to activate/deactivate
  },
  "brjs2":{
    "hover": "ALAGOAS",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs3":{
    "hover": "AMAPÁ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs4":{
    "hover": "AMAZONAS",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs5":{
    "hover": "BAHIA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs6":{
    "hover": "CEARÁ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs7":{
    "hover": "DISTRITO FEDERAL",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs8":{
    "hover": "ESPÍRITO SANTO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs9":{
    "hover": "GOIÁS",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs10":{
    "hover": "MARANHÃO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs11":{
    "hover": "MATO GROSSO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs12":{
    "hover": "MATO GROSSO DO SUL",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs13":{
    "hover": "MINAS GERAIS",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs14":{
    "hover": "PARANÁ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs15":{
    "hover": "PARAÍBA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs16":{
    "hover": "PARÁ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs17":{
    "hover": "PERNAMBUCO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs18":{
    "hover": "PIAUÍ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs19":{
    "hover": "RIO DE JANEIRO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs20":{
    "hover": "RIO GRANDE DO NORTE",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs21":{
    "hover": "RIO GRANDE DO SUL",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs22":{
    "hover": "RONDÔNIA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs23":{
    "hover": "RORAIMA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs24":{
    "hover": "SANTA CATARINA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs25":{
    "hover": "SERGIPE",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs26":{
    "hover": "SÃO PAULO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs27":{
    "hover": "TOCANTINS",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "general":{
    "borderColor": "#9CA8B6",
    "visibleNames": "#adadad",
  }
};