﻿var brjsconfig = {
  "brjs1":{
    "hover": "ACRE",//info of the popup
    "url": "https://www.html5interactivemaps.com/",//link to any webpage
    "target": "same_window",// use "new_window", "same_window", "modal", or "none"
    "upColor": "#FFFFF3",//default color
    "overColor": "#ECFFB3",//highlight color
    "downColor": "#cae9af",//clicking color
    "active": true//true/false to activate/deactivate
  },
  "brjs2":{
    "hover": "<b><u>ALAGOAS</u></b><br>Write any text and load images",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#f1ffc8", "overColor": "#d9ff66", "downColor": "#cae9af",
    "active": true
  },
  "brjs3":{
    "hover": "<b><u>AMAPÁ</u></b><br><span style='color: #bcbcbc;'>Street Address:</span><br>&nbsp;321 Example, Address 54321<br><span style='color: #bcbcbc;'>Telephone:</span><br>&nbsp;(256) 555-4321 / (256) 555-1234",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#d7f57a", "overColor": "#beef2a", "downColor": "#cae9af",
    "active": true
  },
  "brjs4":{
    "hover": "<b><u>AMAZONAS</u></b><br><span style='color: #999;'>*Click to open a webpage*</span>",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#f1ffc8", "overColor": "#d9ff66", "downColor": "#cae9af",
    "active": true
  },
  "brjs5":{
    "hover": "<b><u>BAHIA</u></b><br><span style='color: #999;'>Click to open a modal window!</span><br><span style='color: #ff6666;'><b>Modal Window Option is Compatible<br> with Bootstrap Only.</b></span>",
    "url": "#mymodal", "target": "modal",
    "upColor": "#edff66", "overColor": "#cbe600", "downColor": "#cae9af",
    "active": true
  },
  "brjs6":{
    "hover": "CEARÁ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#E0E2E2", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": false
  },
  "brjs7":{
    "hover": "DISTRITO FEDERAL",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs8":{
    "hover": "ESPÍRITO SANTO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs9":{
    "hover": "GOIÁS",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs10":{
    "hover": "MARANHÃO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs11":{
    "hover": "MATO GROSSO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs12":{
    "hover": "MATO GROSSO DO SUL",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs13":{
    "hover": "<b><u>MINAS GERAIS</u></b><br>Write any text and load images",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#f1ffc8", "overColor": "#d9ff66", "downColor": "#cae9af",
    "active": true
  },
  "brjs14":{
    "hover": "PARANÁ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs15":{
    "hover": "PARAÍBA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs16":{
    "hover": "PARÁ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs17":{
    "hover": "PERNAMBUCO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs18":{
    "hover": "PIAUÍ",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs19":{
    "hover": "<b><u>RIO DE JANEIRO</u></b><br><span style='color: #999;'>*Click to open a webpage*</span>",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#f1ffc8", "overColor": "#d9ff66", "downColor": "#cae9af",
    "active": true
  },
  "brjs20":{
    "hover": "RIO GRANDE DO NORTE",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs21":{
    "hover": "RIO GRANDE DO SUL",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs22":{
    "hover": "RONDÔNIA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs23":{
    "hover": "RORAIMA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs24":{
    "hover": "SANTA CATARINA",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#E0E2E2", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": false
  },
  "brjs25":{
    "hover": "<b><u>SERGIPE</u></b><br>Write any text and load images",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#f1ffc8", "overColor": "#d9ff66", "downColor": "#cae9af",
    "active": true
  },
  "brjs26":{
    "hover": "SÃO PAULO",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "brjs27":{
    "hover": "TOCANTINS",
    "url": "https://www.html5interactivemaps.com/", "target": "same_window",
    "upColor": "#FFFFF3", "overColor": "#ECFFB3", "downColor": "#cae9af",
    "active": true
  },
  "general":{
    "borderColor": "#9CA8B6",
    "visibleNames": "#adadad"
  }
};